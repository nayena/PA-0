package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StudentFloorTest {

	@Test
	void test() {
		throw new UnsupportedOperationException("not implemented");
	}

}
