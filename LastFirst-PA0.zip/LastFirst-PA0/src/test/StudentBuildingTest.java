package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StudentBuildingTest {

	@Test
	void test() {
		throw new UnsupportedOperationException("not implemented");
	}
}
