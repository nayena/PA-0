package main;

public class Floor {

	public void enterFloor(Person person) {
		throw new UnsupportedOperationException();
	}
}
