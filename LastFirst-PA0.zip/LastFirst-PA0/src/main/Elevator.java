package main;

public class Elevator {

	/**
	 * This specifies the number of people that can be brought to their floors by an Elevator 
	 * instance at any given time. 
	 * <p>DO NOT REMOVE THIS FIELD</p>
	 * <p>You may edit it. But keep it public.</p>
	 */
	public static int maxOccupants = 3;
	
	public void createJob(Person person, int floor) {
		throw new UnsupportedOperationException();
	}
	
	public void processAllJobs() {
		throw new UnsupportedOperationException();
	}
	
	public void processJob(Job job) {
		throw new UnsupportedOperationException();
	}
	
	public void exit(Person person, int floor) {
		throw new UnsupportedOperationException();
	}
}