package main;

public class Building {

	public Building(int numFloors) {
		throw new UnsupportedOperationException();
	}
	
	public boolean enterElevatorRequest(Person person, int floor) {
		throw new UnsupportedOperationException();
	}
	
	public void startElevator() {
		throw new UnsupportedOperationException();
	}
	
	public void enterFloor(Person person, int floor) {
		throw new UnsupportedOperationException();
	}
}
