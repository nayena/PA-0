package main;

public class Person {
	
	public Person(String firstName, String lastName) {
		throw new UnsupportedOperationException();
	}

	public boolean enterBuilding(Building building, int floor) {
		throw new UnsupportedOperationException();
	}
	
	public String getLocation() {
		throw new UnsupportedOperationException();
	}
}
